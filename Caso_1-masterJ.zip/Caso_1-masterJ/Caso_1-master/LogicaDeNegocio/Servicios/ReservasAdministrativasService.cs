﻿using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;
using AccesoADatos.Data;
using LogicaDeNegocio.Interfaces;

namespace LogicaDeNegocio.Servicios
{
    public class ReservasAdministrativasService : IReservasAdministrativasService
    {
        private readonly AppDBContext _db;
        public ReservasAdministrativasService(AppDBContext db) => _db = db;

        public async Task<IReadOnlyList<ReservaAdminDto>> ListarAsync(int? idServicio)
        {
            var query = _db.Citas.AsNoTracking().AsQueryable();
            if (idServicio.HasValue)
                query = query.Where(c => c.IdServicio == idServicio.Value);

            return await query
                .OrderByDescending(c => c.FechaDeRegistro)
                .Select(c => new ReservaAdminDto
                {
                    NombrePersona = c.NombreDeLaPersona,
                    Telefono = c.Telefono,
                    Correo = c.Correo,
                    Identificacion = c.Identificacion,
                    MontoTotal = c.MontoTotal,
                    FechaNacimiento = c.FechaNacimiento,
                    FechaCita = c.FechaDeLaCita,
                    FechaRegistro = c.FechaDeRegistro
                })
                .ToListAsync();
        }
    }
}

