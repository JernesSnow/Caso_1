﻿using System;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace LogicaDeNegocio.Interfaces
{
    public class ReservaAdminDto
    {
        public string NombrePersona { get; set; } = "";
        public string Telefono { get; set; } = "";
        public string Correo { get; set; } = "";
        public string Identificacion { get; set; } = "";
        public decimal MontoTotal { get; set; }
        public DateTime FechaNacimiento { get; set; }
        public DateTime FechaCita { get; set; }
        public DateTime FechaRegistro { get; set; }
    }

    public interface IReservasAdministrativasService
    {
        Task<IReadOnlyList<ReservaAdminDto>> ListarAsync(int? idServicio);
    }
}

