﻿namespace AccesoADatos
{
    public class Class1
    {

    }
}
