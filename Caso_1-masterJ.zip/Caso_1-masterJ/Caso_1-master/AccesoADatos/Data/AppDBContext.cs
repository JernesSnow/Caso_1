﻿using Microsoft.EntityFrameworkCore;
using AccesoADatos.Models;

namespace AccesoADatos.Data
{
    public class AppDBContext : DbContext
    {
        public AppDBContext(DbContextOptions<AppDBContext> options) : base(options) { }

        public DbSet<Citas> Citas => Set<Citas>();
        public DbSet<Servicio> Servicios => Set<Servicio>();

        protected override void OnModelCreating(ModelBuilder mb)
        {
            mb.Entity<Servicio>(e =>
            {
                e.ToTable("Servicios");
                e.HasKey(x => x.Id);
                e.Property(x => x.Monto).HasColumnType("decimal(18,2)");
                e.Property(x => x.IVA).HasColumnType("decimal(18,2)");
            });

            mb.Entity<Citas>(e =>
            {
                e.ToTable("Citas");
                e.HasKey(x => x.Id);
                e.Property(x => x.MontoTotal).HasColumnType("decimal(18,2)");
                e.HasOne(x => x.Servicio)
                 .WithMany(s => s.Citas)
                 .HasForeignKey(x => x.IdServicio);
            });
        }
    }
}
