﻿using Microsoft.EntityFrameworkCore;
using AccesoADatos.Data;
using LogicaDeNegocio.Interfaces;
using LogicaDeNegocio.Servicios;

var builder = WebApplication.CreateBuilder(args);
builder.Services.AddControllersWithViews();
builder.Services.AddDbContext<AppDBContext>(opts =>
    opts.UseSqlServer(builder.Configuration.GetConnectionString("CASO_PRACTICO_MEDICO")));
builder.Services.AddScoped<IReservasAdministrativasService, ReservasAdministrativasService>();
var app = builder.Build();
if (!app.Environment.IsDevelopment()) { app.UseExceptionHandler("/Home/Error"); }
app.UseStaticFiles(); app.UseRouting(); app.UseAuthorization();
app.MapControllerRoute(name: "default", pattern: "{controller=Home}/{action=Index}/{id?}");
app.Run();

