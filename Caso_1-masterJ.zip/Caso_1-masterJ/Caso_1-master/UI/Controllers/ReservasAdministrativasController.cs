﻿using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using LogicaDeNegocio.Interfaces;

namespace UI.Controllers
{
    public class ReservasAdministrativasController : Controller
    {
        private readonly IReservasAdministrativasService _service;
        public ReservasAdministrativasController(IReservasAdministrativasService service)
        {
            _service = service;
        }

        [HttpGet]
        public async Task<IActionResult> Index([FromQuery] int? servicioId)
        {
            var modelo = await _service.ListarAsync(servicioId);
            ViewBag.ServicioId = servicioId;
            return View(modelo);
        }
    }
}

